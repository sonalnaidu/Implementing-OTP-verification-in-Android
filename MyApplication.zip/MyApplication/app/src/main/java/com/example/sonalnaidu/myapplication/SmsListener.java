package com.example.sonalnaidu.myapplication;

/**
 * Created by Sonal Naidu on 23-03-2018.
 */

public interface SmsListener {
    public void messageReceived(String messageText);
}
